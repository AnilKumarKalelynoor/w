# !/bin/sh
cp anil bansi 
mv bansi naresh
